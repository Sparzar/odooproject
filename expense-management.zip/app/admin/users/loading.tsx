export default function Loading() {
  return <div className="p-6 text-muted-foreground">Loading users…</div>
}
